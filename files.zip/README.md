# Hisab Kitab – GitHub par daalne ke steps

Files: index.html (poora app), manifest.webmanifest, sw.js, icon-192.png, icon-512.png, tests.js

## IMPORTANT – purana data bachane ke liye
Data us link (address) se bandha hota hai jahan app khula tha. NAYA repo / NAYA link banaoge to data khali dikhega.
- Pehle se GitHub par app hai? Usi repo me files REPLACE karo (Add file -> Upload files, same naam). Link wahi rahega, data bacha rahega.
- Purana data nikalna ho: purane link/app me Settings -> Backup dabao, file save karo. Naye link me Settings -> Restore se daalo.
- Claude wale purane link me data hai to wahi same browser me kholo, Settings -> Backup.

## Pehli baar GitHub par
1. github.com par login / free account.
2. "+" -> New repository -> Name: hisab-kitab -> Public -> Create.
3. "uploading an existing file" -> 5 files upload (index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png) -> Commit changes.
4. Settings -> Pages -> Deploy from a branch -> main, / (root) -> Save.
5. 1-2 min baad link: https://AAPKA-USERNAME.github.io/hisab-kitab/  (duniya me koi bhi khol sakta hai)
6. Phone me kholo: Android Chrome -> Install app; iPhone Safari -> Share -> Add to Home Screen.

## Naya version daalna
Repo me files same naam se upload (replace) -> Commit. sw.js me hisab-v2 ko hisab-v3 karo.

## Features
- Member add: Settings -> Add member (naam, mobile, photo optional). "Invite on WhatsApp" se app ka link us member ko jaata hai.
- Barcode: Add + -> "Scan barcode". Item ka naam internet se (Open Food Facts) aata hai, price aap daalo; agli baar wahi item scan karo to naam+price khud aa jayega.
- WhatsApp update: expense save hone par "Tell roommates on WhatsApp" (ya Expenses me WhatsApp button) -> message taiyaar, aap Send dabate ho.
- Backup ko WhatsApp par bhejo: Settings -> Share backup. Dusra banda Settings -> Restore se le.

## Permissions
Camera: scan dabane par browser khud permission poochta hai -> Allow. Storage ki permission nahi chahiye (app khud permanent storage maangta hai).
APK banana ho: pwabuilder.com par link daalo -> Android -> APK; camera permission usme apne aap judti hai.

## Limits (sach)
- Barcode auto-scan sirf Android Chrome me. iPhone par number type karna padega.
- Open Food Facts me zyadatar packaged food milta hai; price kabhi nahi milta.
- Sabka data live sync nahi hota, har phone ka alag hai. Live sync + admin ke liye server (Firebase) alag se jodna padega.
- WhatsApp par message khud-ba-khud nahi jaata (uske liye paid WhatsApp Business API chahiye); app message taiyaar karke WhatsApp khol deta hai.
- Member hataane ka option nahi hai (purane hisab na bigden).
